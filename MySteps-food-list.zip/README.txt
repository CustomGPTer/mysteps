MySteps food list
=================

The food list built into the MySteps app for Android, as an SQLite database.

Tables
  food      id, name, brand, code (barcode), kcal, prot, carb, sugar, fat, sat, fibre, salt
            (all per 100 g), serving_g, serving_label, pop, src (0 everyday food, 1 product)
  food_fts  full-text search over the normalised name and brand
  word      every word in the list with how many foods use it
  info      version and counts

Sources and licences
  Products (src = 1): (c) Open Food Facts contributors, https://world.openfoodfacts.org
  Made available under the Open Database Licence 1.0:
  https://opendatacommons.org/licenses/odbl/1-0/
  Individual contents are under the Database Contents Licence 1.0:
  https://opendatacommons.org/licenses/dbcl/1-0/
  This is a trimmed version: UK products with complete, consistent nutrition and a barcode,
  with duplicates removed.

  Everyday foods (src = 0): McCance and Widdowson's The Composition of Foods Integrated
  Dataset 2021, Crown copyright, used under the Open Government Licence v3.0:
  https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/

Product details can vary, so please check the pack.
